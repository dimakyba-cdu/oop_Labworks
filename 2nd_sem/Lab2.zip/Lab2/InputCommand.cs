namespace Lab2
{
  public class InputCommand(CalculatorEngine calculator, string number) : CalculatorCommand(calculator)
  {
    private readonly string number = number;

    public override void Execute() => calculator.ProcessNumber(number);
  }
}
