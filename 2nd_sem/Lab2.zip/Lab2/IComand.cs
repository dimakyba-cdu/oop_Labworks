namespace Lab2
{
  public interface ICommand
  {
    void Execute();
    void Undo();
  }
}
